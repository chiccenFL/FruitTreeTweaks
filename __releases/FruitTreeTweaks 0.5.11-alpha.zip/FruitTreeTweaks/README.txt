chiccen's Updated Fruit Tree Tweaks For 1.6

Original mod by aedenthorn

==========================

This mod doesn't change much, just updated a couple lines to code to make it current with 1.6
If I broke something, let me know. I don't actually intend to use the mod myself so I won't know if there are major bugs

==========================


Reqires most recent version of SMAPI

If you have further questions, you can reach me on Discord @chiccen


I will take this mod down at the request of aedenthorn